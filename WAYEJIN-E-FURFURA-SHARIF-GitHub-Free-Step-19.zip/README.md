# WAYEJIN E-FURFURA SHARIF — GitHub Free Step 19

এই প্যাকেজটি GitHub Pages-এর জন্য তৈরি করা একটি সম্পূর্ণ ফ্রি static version।

## কী আছে
- Premium responsive homepage
- Wazeen Registration
- Application number generation
- Local Admin demo (approve)
- Wazeen ID generation
- Public verification
- Wazeen directory
- News & Events
- Mobile responsive design

## গুরুত্বপূর্ণ
GitHub Pages শুধুমাত্র static website host করে। এই ধাপে registration/admin data `localStorage`-এ থাকে, অর্থাৎ একই browser/device-এর মধ্যে demo হিসেবে কাজ করে। এটি central database নয়।

পরবর্তী ধাপে free backend/database যুক্ত করলে:
Registration → Central Database → Admin Approval → Wazeen ID → QR → Public Verification
সব ডিভাইস থেকে ব্যবহার করা যাবে।

## GitHub Pages-এ প্রকাশ
1. GitHub-এ নতুন repository তৈরি করুন।
2. এই ZIP-এর ভেতরের সব ফাইল repository-এর root-এ upload করুন।
3. Settings → Pages → Deploy from a branch নির্বাচন করুন।
4. Branch: main এবং Folder: / (root) নির্বাচন করে Save করুন।
5. কিছুক্ষণ পর GitHub আপনাকে free `github.io` address দেবে।

## নিরাপত্তা
এই static demo-তে কোনো real admin password বা sensitive document রাখবেন না। Central backend যুক্ত করার আগে production security, authentication, private file storage এবং privacy policy আলাদাভাবে ঠিক করতে হবে।
