# DEPLOYMENT CHECKLIST
[ ] GitHub account ready
[ ] New repository created
[ ] All files uploaded to repository root
[ ] Settings > Pages enabled
[ ] main branch selected
[ ] Website URL opened successfully
[ ] Registration test submitted
[ ] Admin test approval checked
[ ] Verification test checked
